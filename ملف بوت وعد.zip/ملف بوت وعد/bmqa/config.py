import redis
r = redis.Redis('localhost',decode_responses=True)

token = "6640072194:AAEOXc7HW3pubG3g_XvAqkQZgMrGGtYIPRk"
Dev_Zaid = token.split(':')[0]
sudo_id = 5802896978
botUsername = "CQJBOT"

from kvsqlite.sync import Client as DB
ytdb = DB('ytdb.sqlite')
sounddb = DB('sounddb.sqlite')
wsdb = DB('wsdb.sqlite')